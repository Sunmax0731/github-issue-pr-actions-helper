# 要件定義

## 目的

GitHub Issue/PR/Actions補助 は、GitHub画面上でIssue、PR、Actionsの確認作業と証跡を補助する。

## MVP範囲

- 入力データから必須項目の不足を検出する。
- 結果をJSON、Markdown、HTMLまたはホストアプリ内UIで確認できるようにする。
- 自動テストと手動テスト手順を同梱する。
- 競合比較にもとづく評価基準を docs/evaluation-criteria.md に保持する。

## 対象外

- 実ファイルの破壊的な変更。
- 外部APIへの本番実行。
- ユーザー承認なしの公開、配布、削除。

## 成功条件

- `npm test` が成功する。
- docs/qcds-evaluation.md のQCDS全観点が A- 以上である。
- 導入手順、ユーザーガイド、手動テスト手順が利用者目線で読める。
