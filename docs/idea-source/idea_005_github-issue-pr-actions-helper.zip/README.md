# GitHub Issue・PR・Actions補助 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | ChromeExtension |
| No. | 5 |
| 分野 | 開発・GitHub運用 |
| アイデア | GitHub Issue・PR・Actions補助 |
| リポジトリ名 | github-issue-pr-actions-helper |
| 概要 | Issueテンプレ、PRコメント、Actions失敗ログを横断表示する。 入力、確認、履歴保存、次アクションを同じ作業単位で扱えるようにする。 |
| 課題 | GitHub画面で必要情報が分散し、失敗原因や次タスクを見落とす。 |
| 類似サービス・アプリ | Pocket, Raindrop.io, OneTab, Evernote Web Clipper, GitHub UI, Similarweb, Grammarly |
| 差別化ポイント | Issue本文、受け入れ条件、CI要約を同じブラウザ補助にまとめる。 |

## 目的

このZIPには、`ChromeExtension` 領域のアイデア `GitHub Issue・PR・Actions補助` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
