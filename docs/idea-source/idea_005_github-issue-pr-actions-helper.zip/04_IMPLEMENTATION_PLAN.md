# 04 実装計画: GitHub Issue・PR・Actions補助

## フェーズ1: 土台作成

- プロジェクトの雛形を作成する。
- 実行コマンドと検証コマンドをREADMEに追加する。
- サンプルデータと基本UIまたは操作面を追加する。

## フェーズ2: 中核フロー

- 1つの入力経路を実装する。
- プレビューまたは一覧ビューを実装する。
- 中核となる `開発・GitHub運用` の処理を1つ実装する。
- エラーと実行ログを追加する。

## フェーズ3: 実用MVP

- プリセット、履歴、再試行、書き出し/保存を追加する。
- 代表的な失敗処理を追加する。
- 手動確認チェックリストを追加する。

## フェーズ4: 仕上げ / リリース

- 空状態、読み込み中、エラー状態を整える。
- テストと手動検証を実行する。
- 既知の問題と次フェーズを文書化する。

## 初期ディレクトリ案

```text
github-issue-pr-actions-helper/
  README.md
  docs/
    requirements.md
    specification.md
    design.md
    test-plan.md
  src/
    app/
    domain/
    infrastructure/
    ui/
  tests/
  samples/
```
