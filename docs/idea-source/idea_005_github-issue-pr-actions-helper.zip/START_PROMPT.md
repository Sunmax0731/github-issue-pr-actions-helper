あなたはこのアイデアの実装担当エージェントです。要件定義、仕様、設計、MVP実装、検証まで、この開発パックに沿って進めてください。

## 対象アイデア

- 親分類: Plugins
- 領域: ChromeExtension
- No.: 5
- 分野: 開発・GitHub運用
- アイデア: GitHub Issue・PR・Actions補助
- リポジトリ名: github-issue-pr-actions-helper

## 元アイデア

- 概要: Issueテンプレ、PRコメント、Actions失敗ログを横断表示する。 入力、確認、履歴保存、次アクションを同じ作業単位で扱えるようにする。
- 課題: GitHub画面で必要情報が分散し、失敗原因や次タスクを見落とす。
- 類似サービス・アプリ: Pocket, Raindrop.io, OneTab, Evernote Web Clipper, GitHub UI, Similarweb, Grammarly
- 差別化ポイント: Issue本文、受け入れ条件、CI要約を同じブラウザ補助にまとめる。

## 最初に行うこと

1. このZIP内の `01_REQUIREMENTS.md`、`02_SPECIFICATION.md`、`03_DESIGN.md` を読む。
2. 実装前に未決事項を洗い出す。
3. 既存リポジトリがある場合は、先に README、docs、Issue、テスト、現在のアーキテクチャを確認する。
4. 新規リポジトリの場合は、`04_IMPLEMENTATION_PLAN.md` のMVPから開始する。
5. 実装前に、プラットフォーム、保存方式、主要ユーザーフロー、検証方法を明記する。

## 領域別の重点事項

- ホストアプリのバージョン、権限、パネル/メニュー導線、ファイル入出力境界を明確にする。
- ホストアプリのデータモデル、選択状態、書き出しパイプライン、失敗パターンを前提に設計する。
- サンプルプロジェクトと実際のホストアプリ操作で検証する。

## Done Means

- The MVP works.
- The main flow has been manually verified.
- Test or verification steps are repeatable.
- README or usage notes are updated.
- Remaining work is captured in release checklist or issues.
